﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelloWorld : MonoBehaviour {

	public void HeyThere(){
		Debug.Log("Hello world! This is main camera speaking!");
	}
}
