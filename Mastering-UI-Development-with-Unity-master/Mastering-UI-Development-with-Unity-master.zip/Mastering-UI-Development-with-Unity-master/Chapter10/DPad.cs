﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DPad : MonoBehaviour {

	public void PressUp(){
		Debug.Log("up button");
	}

	public void PressDown(){
		Debug.Log("down button");
	}

	public void PressLeft(){
		Debug.Log("left button");
	}

	public void PressRight(){
		Debug.Log("right button");
	}
}
